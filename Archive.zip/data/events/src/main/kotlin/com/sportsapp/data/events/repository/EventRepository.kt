package com.sportsapp.data.events.repository

import com.sportsapp.core.common.util.Resource
import com.sportsapp.data.events.model.Event
import kotlinx.coroutines.flow.Flow

interface EventRepository {

}