package com.sportsapp.core.common.util

import java.io.IOException

class NoConnectivityException : IOException("No internet connection")