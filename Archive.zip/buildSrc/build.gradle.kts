plugins {
    `kotlin-dsl`
}

repositories {
    google()
    mavenCentral()
}